<?php
/*
 * Lang file for team
 *
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package team
*/

$lang_team = array(
	'Team'		=> 'Команда: ',
	'Teams'		=> 'Команда',
	'TeamList'	=> 'Командам',
);
?>
