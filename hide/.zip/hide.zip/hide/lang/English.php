<?php
/*
 * manifest file for hide
 *
 * @copyright Copyright (C) 2009 KANekT @ http://blog.teamrip.ru
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package hide
*/

$lang_hide = array(
	'Hidden text guest'			=>	'Before you can view this text, you have to %s.',
	'login'                     =>  'login',
	'Hidden text'				=>	'Hidden text',
	'Hidden count text begin'	=>	'You need',
	'Hidden count text end'		=>	'messages or more to view hidden text.',
	'Hidden text group'			=>  'Hidden text for group ',
);
?>