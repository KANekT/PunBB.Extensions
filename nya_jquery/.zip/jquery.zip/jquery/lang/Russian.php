<?php
/*
 * Lang file for jQuery
 *
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package jQuery by KANekT
*/

$lang_jQuery = array(
	'Topic features head'	=>	'jQuery',
	'Topic legend'			=>	'Страницы с jQuery',
);
?>
