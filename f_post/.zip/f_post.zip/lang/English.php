<?php
/**
 * Language definitions used in first topic
 * 
 *
 * @copyright Copyright (C) 2008 PunBB, partially based on code copyright (C) 2008 FluxBB.org
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package f_post
 */

$lang_f_post = array(
	'First post' => 'Lock the first post in the topic',
);
