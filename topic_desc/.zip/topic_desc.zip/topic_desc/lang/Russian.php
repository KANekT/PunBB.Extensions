<?php
/*
 * Lang file for topic description
 *
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package topic description
*/

$lang_topic = array(
	'Topic Description'		=> 	'Описание',
	'Topic features head'	=>	'Настройка Описание Тем',
	'Topic legend'			=>	'Настройка Описание Тем',
	'Topic enable'			=>	'Показывать описание темы после названия',
	'Topic enable mouse'	=>	'Показывать описание темы когда пользователь наводит курсор мыши на ссылку темы',
	'Topic enable and mouse'=>	'Показывать описание темы после названия и когда пользователь наводит курсор мыши на ссылку темы',
);
?>
