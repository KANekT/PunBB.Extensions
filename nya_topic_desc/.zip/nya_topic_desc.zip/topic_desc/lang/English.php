<?php
/*
 * Lang file for topic description
 *
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package topic description
*/

$lang_topic = array(
	'Topic Description'		=> 'Description',
	'Topic features head' => 'Configure Topic Description',
	'Topic legend' => 'Configure Topic Description',
	'Topic enable' => 'Show the description after topic',
	'Topic enable mouse'	=>	'Show the description when a user mouseover the topic link',
	'Topic enable and mouse'=>	'Show the description after topic and when a user mouseover the topic link',
);
?>
