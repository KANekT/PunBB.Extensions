<?php
$lang_nya_bbcode = array(
	'Hidden text guest'			=>	'Before you can view this text, you have to %s.',
	'login'                     =>  'login',
	'Hidden text'				=>	'Hidden text',
	'Hidden count begin'	=>	'You need',
	'Hidden count end'		=>	'messages or more to view hidden text.',
	'Hidden text group'			=>  'Hidden text for group ',
	'video_uri'			=>	'http://my.video.com/xyz',
	'video_display'		=>	'an embedded video player in your post.<br />You can use any video uri from the following services: youtube, rutube, dailymotion, vimeo, google video.',
	'List info'	=>	'Nya Extended BBCode usable to beautify posts.',
	'Center'	=>	'This text will be centered.',
	'Right'		=>	'This text will align to the right.',
	'Left'		=>	'This text will align to the left.',
	'Justify'	=>	'Some longer text to let you see that this text is spread over the entire available space of the post. This text alignment is called justify. Center, Right and Justify bbcode is now done through css. No modifications done to the original parser code. Tested in Internet Explorer 7 and FireFox 3.6 Version 1.1.0 is considered as a stable release version of this extension.',
	'Note'		=>	'Your post is edited. Corrected the URL to the linked image.',
	'str_Note'	=>	'Note from: ',
	'Highlight'	=>	'This text is highlighted.',
	'Box'		=>	'Makes a box like this.',
	'str_Spoiler'	=>	'SPOILER',
	'Spoiler'	=>	'This text is hidden until clicked.',
	'acronym'	=>	'XSS',
	'acronym text'	=>	'Сross Site Sсriрting',
	's text'	=>	'text witn code S',
	'search'	=>	'Search',
	'search text'	=>	'punbb',
	
);
?>