<?php
/*
 * manifest file for hide
 *
 * @copyright Copyright (C) 2009 KANekT @ http://blog.teamrip.ru
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package hide
*/

$lang_hide = array(
	'Hidden text guest'		=>    'Вы должны зайти под %s, чтобы увидеть скрытый текст.',
	'login'                 =>	  'своим именем',
	'Hidden text'           =>    'Скрытый текст',
	'Hidden count begin'    =>    'Количество Ваших сообщений должно быть равным',
	'Hidden count end'      =>    'или более, чтобы увидеть скрытый текст.',
	'Hidden text group'		=>    'Скрытый текст для группы ',
);
?>
