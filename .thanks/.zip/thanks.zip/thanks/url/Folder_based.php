<?php
/**
 * Folder based SEF URL scheme.
 *
 * @copyright (C) 2008-2009 PunBB
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package thanks
 */

	$forum_url['thanks_user'] = 'thanks_user/$1/';
	$forum_url['thanks_post'] = 'extensions/thanks/viewp.php?id=$1&amp;lang=$2';

?>