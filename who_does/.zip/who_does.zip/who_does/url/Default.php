<?php
/**
 * Default SEF URL scheme.
 *
 * @copyright Copyright (C) 2008 PunBB, partially based on code copyright (C) 2008 FluxBB.org
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package reputation
 */

$forum_url['who_does_view'] = 'misc.php?section=who_does';
?>
