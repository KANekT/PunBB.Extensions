<?php
/*
 * lang file for hide
 *
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package hide
*/

$lang_jqbb = array(
	'Hidden text guest'			=>	'Before you can view this text, you have to %s.',
	'login'                     =>  'login',
	'Hidden text'				=>	'Hidden text',
	'Hidden count begin'	=>	'You need',
	'Hidden count end'		=>	'messages or more to view hidden text.',
	'Hidden text group'			=>  'Hidden text for group ',
	'List info'	=>	'BBCode to hide or show posts or parts of posts.',
	'str_Spoiler'	=>	'SPOILER',
	'str_Hide'	=>	'Hide',
	'str_Show'	=>	'Show',
	'video_uri'			=>	'http://my.video.com/xyz',
	'video_display'		=>	'an embedded video player in your post.<br />You can use any video uri from the following services: youtube, dailymotion, vimeo, google video.',
	);
?>